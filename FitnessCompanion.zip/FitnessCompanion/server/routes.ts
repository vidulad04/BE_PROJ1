import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";
import { insertWorkoutPlanSchema, insertWorkoutLogSchema, insertProgressSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Exercise routes
  app.get("/api/exercises", async (_req, res) => {
    const exercises = await storage.getExercises();
    res.json(exercises);
  });

  app.get("/api/exercises/:id", async (req, res) => {
    const exercise = await storage.getExercise(Number(req.params.id));
    if (!exercise) {
      return res.status(404).send("Exercise not found");
    }
    res.json(exercise);
  });

  // Workout plan routes
  app.get("/api/workout-plans", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const plans = await storage.getWorkoutPlans(req.user.id);
    res.json(plans);
  });

  app.post("/api/workout-plans", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const plan = await storage.createWorkoutPlan({
      ...insertWorkoutPlanSchema.parse(req.body),
      userId: req.user.id,
    });
    res.status(201).json(plan);
  });

  // Workout log routes
  app.get("/api/workout-logs", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const logs = await storage.getWorkoutLogs(req.user.id);
    res.json(logs);
  });

  app.post("/api/workout-logs", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const log = await storage.createWorkoutLog({
      ...insertWorkoutLogSchema.parse(req.body),
      userId: req.user.id,
    });
    res.status(201).json(log);
  });

  // Progress tracking routes
  app.get("/api/progress", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const progress = await storage.getProgress(req.user.id);
    res.json(progress);
  });

  app.post("/api/progress", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const progress = await storage.createProgress({
      ...insertProgressSchema.parse(req.body),
      userId: req.user.id,
    });
    res.status(201).json(progress);
  });

  const httpServer = createServer(app);
  return httpServer;
}
