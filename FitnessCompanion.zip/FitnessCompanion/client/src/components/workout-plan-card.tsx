import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { WorkoutPlan } from "@shared/schema";
import { ListChecks, Play } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface WorkoutPlanCardProps {
  plan?: WorkoutPlan;
  isLoading?: boolean;
}

export default function WorkoutPlanCard({ plan, isLoading }: WorkoutPlanCardProps) {
  const { toast } = useToast();

  const startWorkout = useMutation({
    mutationFn: async () => {
      if (!plan) return;
      const res = await apiRequest("POST", "/api/workout-logs", {
        workoutPlanId: plan.id,
        date: new Date(),
        completed: false,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workout-logs"] });
      toast({
        title: "Workout Started",
        description: "Good luck with your workout!",
      });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-2/3" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-2/3" />
        </CardContent>
      </Card>
    );
  }

  if (!plan) return null;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <ListChecks className="h-5 w-5 text-primary" />
            {plan.name}
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          {plan.description || "No description provided"}
        </p>
        
        <Button
          className="w-full"
          onClick={() => startWorkout.mutate()}
          disabled={startWorkout.isPending}
        >
          <Play className="h-4 w-4 mr-2" />
          Start Workout
        </Button>
      </CardContent>
    </Card>
  );
}
