import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Exercise } from "@shared/schema";
import { Dumbbell } from "lucide-react";
import PoseDetection from "./PoseDetection";
import { useState } from "react";

interface ExerciseCardProps {
  exercise?: Exercise;
  isLoading?: boolean;
}

export default function ExerciseCard({ exercise, isLoading }: ExerciseCardProps) {
  const [formScore, setFormScore] = useState<number>();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-2/3" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-2/3" />
        </CardContent>
      </Card>
    );
  }

  if (!exercise) return null;

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="cursor-pointer hover:bg-accent transition-colors">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">{exercise.name}</CardTitle>
              <Badge variant="outline">{exercise.difficulty}</Badge>
            </div>
            <CardDescription>{exercise.muscleGroup}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {exercise.description}
            </p>
          </CardContent>
        </Card>
      </DialogTrigger>

      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Dumbbell className="h-5 w-5" />
            {exercise.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <Badge>{exercise.muscleGroup}</Badge>
            <Badge variant="outline">{exercise.difficulty}</Badge>
            {formScore !== undefined && (
              <Badge variant="secondary">Form Score: {formScore.toFixed(0)}%</Badge>
            )}
          </div>

          <div>
            <h4 className="font-semibold mb-2">Description</h4>
            <p className="text-muted-foreground">{exercise.description}</p>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Instructions</h4>
            <div className="space-y-2">
              {exercise.instructions.split('\n').map((step, index) => (
                <p key={index} className="text-sm text-muted-foreground">
                  {step}
                </p>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Form Check</h4>
            <p className="text-sm text-muted-foreground mb-4">
              Use your camera to check your form while performing this exercise.
              Our AI will analyze your posture and provide feedback.
            </p>
            <PoseDetection
              exerciseName={exercise.name}
              onFormEvaluation={setFormScore}
            />
          </div>

          {exercise.demonstrationUrl && (
            <div>
              <h4 className="font-semibold mb-2">Demonstration</h4>
              <img
                src={exercise.demonstrationUrl}
                alt={`${exercise.name} demonstration`}
                className="rounded-lg w-full"
              />
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}