import { Exercise, WorkoutPlan, WorkoutLog, Progress, User, InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Exercise operations
  getExercises(): Promise<Exercise[]>;
  getExercise(id: number): Promise<Exercise | undefined>;
  createExercise(exercise: Omit<Exercise, "id">): Promise<Exercise>;

  // Workout plan operations
  getWorkoutPlans(userId: number): Promise<WorkoutPlan[]>;
  createWorkoutPlan(plan: Omit<WorkoutPlan, "id">): Promise<WorkoutPlan>;
  
  // Workout log operations
  getWorkoutLogs(userId: number): Promise<WorkoutLog[]>;
  createWorkoutLog(log: Omit<WorkoutLog, "id">): Promise<WorkoutLog>;

  // Progress tracking operations
  getProgress(userId: number): Promise<Progress[]>;
  createProgress(progress: Omit<Progress, "id">): Promise<Progress>;

  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private exercises: Map<number, Exercise>;
  private workoutPlans: Map<number, WorkoutPlan>;
  private workoutLogs: Map<number, WorkoutLog>;
  private progressRecords: Map<number, Progress>;
  private currentId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.exercises = new Map();
    this.workoutPlans = new Map();
    this.workoutLogs = new Map();
    this.progressRecords = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Seed some default exercises
    this.seedExercises();
  }

  private getNextId() {
    return this.currentId++;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.getNextId();
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getExercises(): Promise<Exercise[]> {
    return Array.from(this.exercises.values());
  }

  async getExercise(id: number): Promise<Exercise | undefined> {
    return this.exercises.get(id);
  }

  async createExercise(exercise: Omit<Exercise, "id">): Promise<Exercise> {
    const id = this.getNextId();
    const newExercise = { ...exercise, id };
    this.exercises.set(id, newExercise);
    return newExercise;
  }

  async getWorkoutPlans(userId: number): Promise<WorkoutPlan[]> {
    return Array.from(this.workoutPlans.values()).filter(
      (plan) => plan.userId === userId,
    );
  }

  async createWorkoutPlan(plan: Omit<WorkoutPlan, "id">): Promise<WorkoutPlan> {
    const id = this.getNextId();
    const newPlan = { ...plan, id };
    this.workoutPlans.set(id, newPlan);
    return newPlan;
  }

  async getWorkoutLogs(userId: number): Promise<WorkoutLog[]> {
    return Array.from(this.workoutLogs.values()).filter(
      (log) => log.userId === userId,
    );
  }

  async createWorkoutLog(log: Omit<WorkoutLog, "id">): Promise<WorkoutLog> {
    const id = this.getNextId();
    const newLog = { ...log, id };
    this.workoutLogs.set(id, newLog);
    return newLog;
  }

  async getProgress(userId: number): Promise<Progress[]> {
    return Array.from(this.progressRecords.values()).filter(
      (progress) => progress.userId === userId,
    );
  }

  async createProgress(progress: Omit<Progress, "id">): Promise<Progress> {
    const id = this.getNextId();
    const newProgress = { ...progress, id };
    this.progressRecords.set(id, newProgress);
    return newProgress;
  }

  private seedExercises() {
    const defaultExercises: Omit<Exercise, "id">[] = [
      {
        name: "Push-ups",
        description: "Basic chest and triceps exercise",
        muscleGroup: "Chest",
        difficulty: "Beginner",
        instructions: "1. Start in plank position\n2. Lower body\n3. Push back up",
        demonstrationUrl: "https://example.com/pushup.gif"
      },
      {
        name: "Squats",
        description: "Lower body compound exercise",
        muscleGroup: "Legs",
        difficulty: "Beginner",
        instructions: "1. Stand with feet shoulder-width apart\n2. Lower body\n3. Return to standing",
        demonstrationUrl: "https://example.com/squat.gif"
      }
    ];

    defaultExercises.forEach(exercise => {
      this.createExercise(exercise);
    });
  }
}

export const storage = new MemStorage();
