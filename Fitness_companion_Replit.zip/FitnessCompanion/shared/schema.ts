import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  goals: text("goals"),
  fitnessLevel: text("fitnessLevel"),
});

export const exercises = pgTable("exercises", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  muscleGroup: text("muscleGroup").notNull(),
  difficulty: text("difficulty").notNull(),
  instructions: text("instructions").notNull(),
  demonstrationUrl: text("demonstrationUrl"),
});

export const workoutPlans = pgTable("workoutPlans", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  exercises: jsonb("exercises").notNull(), 
});

export const workoutLogs = pgTable("workoutLogs", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  workoutPlanId: integer("workoutPlanId").notNull(),
  date: timestamp("date").notNull(),
  completed: boolean("completed").notNull(),
  notes: text("notes"),
});

export const progressTracking = pgTable("progressTracking", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  exerciseId: integer("exerciseId").notNull(),
  date: timestamp("date").notNull(),
  weight: integer("weight"),
  reps: integer("reps"),
  sets: integer("sets"),
  formScore: integer("formScore"), 
  notes: text("notes"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  goals: true,
  fitnessLevel: true,
});

export const insertExerciseSchema = createInsertSchema(exercises);
export const insertWorkoutPlanSchema = createInsertSchema(workoutPlans);
export const insertWorkoutLogSchema = createInsertSchema(workoutLogs);
export const insertProgressSchema = createInsertSchema(progressTracking);

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Exercise = typeof exercises.$inferSelect;
export type WorkoutPlan = typeof workoutPlans.$inferSelect;
export type WorkoutLog = typeof workoutLogs.$inferSelect;
export type Progress = typeof progressTracking.$inferSelect;