import { useEffect, useRef, useState } from 'react';
import Webcam from 'react-webcam';
import * as tf from '@tensorflow/tfjs';
import * as poseDetection from '@tensorflow-models/pose-detection';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Camera, CameraOff } from 'lucide-react';

interface PoseDetectionProps {
  exerciseName: string;
  onFormEvaluation?: (score: number) => void;
}

export default function PoseDetection({ exerciseName, onFormEvaluation }: PoseDetectionProps) {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [detector, setDetector] = useState<poseDetection.PoseDetector>();
  const [isLoading, setIsLoading] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(false);

  useEffect(() => {
    async function initializeDetector() {
      await tf.ready();
      const model = poseDetection.SupportedModels.MoveNet;
      const detectorConfig = {
        modelType: poseDetection.movenet.modelType.SINGLEPOSE_THUNDER,
      };
      const detector = await poseDetection.createDetector(model, detectorConfig);
      setDetector(detector);
      setIsLoading(false);
    }

    initializeDetector();
  }, []);

  const toggleCamera = () => {
    setIsCameraOn(!isCameraOn);
  };

  useEffect(() => {
    let animationFrameId: number;

    async function detectPose() {
      if (!detector || !webcamRef.current || !canvasRef.current || !isCameraOn) return;

      const video = webcamRef.current.video;
      if (!video || !video.readyState === 4) return;

      const poses = await detector.estimatePoses(video);
      
      if (poses.length > 0) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw keypoints
        poses[0].keypoints.forEach((keypoint) => {
          if (keypoint.score && keypoint.score > 0.3) {
            ctx.beginPath();
            ctx.arc(keypoint.x, keypoint.y, 4, 0, 2 * Math.PI);
            ctx.fillStyle = 'aqua';
            ctx.fill();
          }
        });

        // Evaluate form based on exercise type
        if (onFormEvaluation) {
          const formScore = evaluateForm(poses[0], exerciseName);
          onFormEvaluation(formScore);
        }
      }

      animationFrameId = requestAnimationFrame(detectPose);
    }

    detectPose();

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [detector, isCameraOn, exerciseName, onFormEvaluation]);

  function evaluateForm(pose: poseDetection.Pose, exercise: string): number {
    // Implement form evaluation logic based on exercise type
    // This is a simplified example - you would want to add more sophisticated evaluation
    const keypoints = pose.keypoints;
    let score = 0;

    switch (exercise.toLowerCase()) {
      case 'pushup':
        // Example: Check arm angle for proper pushup form
        const leftShoulder = keypoints.find(k => k.name === 'left_shoulder');
        const leftElbow = keypoints.find(k => k.name === 'left_elbow');
        const leftWrist = keypoints.find(k => k.name === 'left_wrist');
        
        if (leftShoulder && leftElbow && leftWrist) {
          // Calculate angle between shoulder, elbow, and wrist
          const angle = calculateAngle(
            { x: leftShoulder.x, y: leftShoulder.y },
            { x: leftElbow.x, y: leftElbow.y },
            { x: leftWrist.x, y: leftWrist.y }
          );
          
          // Score based on angle (90 degrees is ideal for pushup bottom position)
          score = 100 - Math.abs(90 - angle);
        }
        break;

      case 'squat':
        // Example: Check knee angle for proper squat form
        const leftHip = keypoints.find(k => k.name === 'left_hip');
        const leftKnee = keypoints.find(k => k.name === 'left_knee');
        const leftAnkle = keypoints.find(k => k.name === 'left_ankle');
        
        if (leftHip && leftKnee && leftAnkle) {
          const angle = calculateAngle(
            { x: leftHip.x, y: leftHip.y },
            { x: leftKnee.x, y: leftKnee.y },
            { x: leftAnkle.x, y: leftAnkle.y }
          );
          
          // Score based on angle (90 degrees is ideal for squat bottom position)
          score = 100 - Math.abs(90 - angle);
        }
        break;

      default:
        score = 0;
    }

    return Math.max(0, Math.min(100, score));
  }

  function calculateAngle(
    pointA: { x: number; y: number },
    pointB: { x: number; y: number },
    pointC: { x: number; y: number }
  ): number {
    const vectorAB = {
      x: pointB.x - pointA.x,
      y: pointB.y - pointA.y,
    };
    const vectorBC = {
      x: pointC.x - pointB.x,
      y: pointC.y - pointB.y,
    };

    const dotProduct = vectorAB.x * vectorBC.x + vectorAB.y * vectorBC.y;
    const magnitudeAB = Math.sqrt(vectorAB.x * vectorAB.x + vectorAB.y * vectorAB.y);
    const magnitudeBC = Math.sqrt(vectorBC.x * vectorBC.x + vectorBC.y * vectorBC.y);

    const angle = Math.acos(dotProduct / (magnitudeAB * magnitudeBC));
    return (angle * 180) / Math.PI;
  }

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0 relative">
        {isLoading ? (
          <div className="flex items-center justify-center h-[480px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="relative">
              {isCameraOn && (
                <>
                  <Webcam
                    ref={webcamRef}
                    className="w-full"
                    mirrored
                    videoConstraints={{
                      width: 640,
                      height: 480,
                      facingMode: "user",
                    }}
                  />
                  <canvas
                    ref={canvasRef}
                    className="absolute top-0 left-0 w-full h-full"
                    width={640}
                    height={480}
                  />
                </>
              )}
            </div>
            <div className="absolute bottom-4 right-4">
              <Button
                variant="secondary"
                size="icon"
                onClick={toggleCamera}
                className="rounded-full"
              >
                {isCameraOn ? (
                  <CameraOff className="h-5 w-5" />
                ) : (
                  <Camera className="h-5 w-5" />
                )}
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
