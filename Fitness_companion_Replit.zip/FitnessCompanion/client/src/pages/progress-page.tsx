import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@shared/schema";
import ProgressChart from "@/components/progress-chart";
import { Loader2 } from "lucide-react";

export default function ProgressPage() {
  const { data: progressData, isLoading } = useQuery<Progress[]>({
    queryKey: ["/api/progress"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Group progress data by exercise
  const progressByExercise = progressData?.reduce((acc, curr) => {
    if (!acc[curr.exerciseId]) {
      acc[curr.exerciseId] = [];
    }
    acc[curr.exerciseId].push(curr);
    return acc;
  }, {} as Record<number, Progress[]>);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Progress Tracking</h1>
        <p className="text-muted-foreground">
          Monitor your fitness improvements over time
        </p>
      </div>

      <div className="grid gap-6">
        {progressByExercise && Object.entries(progressByExercise).map(([exerciseId, data]) => (
          <Card key={exerciseId}>
            <CardHeader>
              <CardTitle>Exercise Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <ProgressChart data={data} />
            </CardContent>
          </Card>
        ))}

        {(!progressData || progressData.length === 0) && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-8 text-center">
              <p className="text-lg font-semibold mb-2">No progress data yet</p>
              <p className="text-sm text-muted-foreground">
                Start logging your workouts to track your progress
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
